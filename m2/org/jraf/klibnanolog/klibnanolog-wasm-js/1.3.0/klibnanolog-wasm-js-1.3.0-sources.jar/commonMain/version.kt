// Generated file. Do not edit!
package org.jraf.klibnanolog
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.3.0"
